require(`./commands.js`)
require(`./events.js`)